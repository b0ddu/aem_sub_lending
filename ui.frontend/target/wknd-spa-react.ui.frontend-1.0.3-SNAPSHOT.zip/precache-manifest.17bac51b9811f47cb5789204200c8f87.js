self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "70575b4d3afd2f25f94f9c09d416fa56",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/index.html"
  },
  {
    "revision": "302ab2ced03217a4d337",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/css/main.fd22afae.chunk.css"
  },
  {
    "revision": "a39f2589b0a85e9f98f6",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.36ae995d.chunk.js"
  },
  {
    "revision": "fd943fe75ea4c4d45ac234d1b512b64a",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/2.36ae995d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "302ab2ced03217a4d337",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/main.fcf1e95b.chunk.js"
  },
  {
    "revision": "947a28bbb1bf3d46b68d",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/js/runtime-main.b0e1d401.js"
  },
  {
    "revision": "19a5bdabd660fde16554c866e650eadc",
    "url": "/etc.clientlibs/wknd-spa-react/clientlibs/clientlib-react/resources/static/media/icon-back.19a5bdab.svg"
  }
]);